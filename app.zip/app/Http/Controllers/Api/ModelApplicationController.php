<?php

namespace App\Http\Controllers\Api;

use App\Models\ModelApplication;
use App\Http\Resources\ModelApplicationResource;
use App\Http\Requests\ModelApplicationStoreRequest;
use App\Http\Requests\ModelApplicationUpdateRequest;
use Harryes\CrudPackage\Http\Controllers\CrudBaseController;

class ModelApplicationController extends CrudBaseController
{
    /**
     * Constructor to bind the model and resource class to the BaseController.
     */
    public function __construct()
    {
        parent::__construct(
            ModelApplication::class,
            ModelApplicationResource::class,
            ModelApplicationStoreRequest::class,
            ModelApplicationUpdateRequest::class
        );
    }
}