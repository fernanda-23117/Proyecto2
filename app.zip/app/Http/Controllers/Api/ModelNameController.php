<?php

namespace App\Http\Controllers\Api;

use App\Models\ModelName;
use App\Http\Resources\ModelNameResource;
use App\Http\Requests\ModelNameStoreRequest;
use App\Http\Requests\ModelNameUpdateRequest;
use Harryes\CrudPackage\Http\Controllers\CrudBaseController;

class ModelNameController extends CrudBaseController
{
    /**
     * Constructor to bind the model and resource class to the BaseController.
     */
    public function __construct()
    {
        parent::__construct(
            ModelName::class,
            ModelNameResource::class,
            ModelNameStoreRequest::class,
            ModelNameUpdateRequest::class
        );
    }
}