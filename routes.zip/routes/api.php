<?php
Route::apiResource('model-applications', 'App\Http\Controllers\Api\ModelApplicationController');
